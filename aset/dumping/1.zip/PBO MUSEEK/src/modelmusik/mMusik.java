/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelmusik;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bedhu
 */
public class mMusik {

    private koneksi con;

    public mMusik() throws SQLException {
        con = new koneksi();
    }

    public DefaultTableModel getTabel() throws SQLException {
        String judulkolom[] = {"Music ID", "Music Name", "Artist", "Genre", "Link"};
        DefaultTableModel modelTabel = new DefaultTableModel(null, judulkolom);
        try {
            String query = "SELECT `music id`, `music name`, `artist name`, `genre type`, `link` FROM `music` m JOIN `genre` g ON (m.`genre id` = g.`genre id`) JOIN `artist` a ON (m.`artist id` = a.`artist id`) ORDER BY `music name`";
            ResultSet hasil = con.getResult(query);
            while (hasil.next()) {
                String kolom[] = new String[judulkolom.length];
                for (int i = 0; i < kolom.length; i++) {
                    kolom[i] = hasil.getString(i + 1);
                }
                modelTabel.addRow(kolom);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return modelTabel;
    }

    public boolean isIdExisted(String id) throws SQLException {
        String query = "select * from `music` where `music id` = " + id;
        ResultSet hasil = con.getResult(query);
        return hasil.next();
    }

    public String getLink(String id) throws SQLException {
        String query = "SELECT `link` FROM `music` WHERE `music id` = '" + id + "'";
        ResultSet hasil = con.getResult(query);
        hasil.next();
        return hasil.getString(1);
    }

    public void create(String id, String music, String idArtist, String idGenre, String link) throws SQLException {
        String query = "INSERT INTO `music`(`music id`, `music name`, `artist id`, `genre id`, `link`) VALUES ('" + id + "','" + music + "','" + idArtist + "','" + idGenre + "','" + link + "')";
        con.execute(query);
    }

    public void update(String id, String music, String idArtist, String idGenre, String link) throws SQLException {
        String query = "UPDATE `music` SET `music name`='" + music + "',`artist id`='" + idArtist + "',`genre id`='" + idGenre + "',`link`='" + link + "' WHERE `music id`='" + id + "'";
        con.execute(query);
    }

    public void delete(String id) throws SQLException {
        String query = "DELETE FROM `music` WHERE `music id` = " + id;
        con.execute(query);
    }
}
