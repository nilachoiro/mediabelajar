/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelmusik;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bedhu
 */
public class mArtist {

    private koneksi con;

    public mArtist() throws SQLException {
        con = new koneksi();
    }

    public DefaultTableModel getTabel() throws SQLException {
        String judulkolom[] = {"Artist ID", "Artist Name"};
        DefaultTableModel modelTabel = new DefaultTableModel(null, judulkolom);
        try {
            String query = "select * from artist order by `artist id`";
            ResultSet hasil = con.getResult(query);
            while (hasil.next()) {
                String kolom[] = new String[judulkolom.length];
                for (int i = 0; i < kolom.length; i++) {
                    kolom[i] = hasil.getString(i + 1);
                }
                modelTabel.addRow(kolom);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return modelTabel;
    }

    public boolean isIdExisted(String id) throws SQLException {
        String query = "select * from `artist` where `artist id` = " + id;
        ResultSet hasil = con.getResult(query);
        return hasil.next();
    }

    public String[] getIdArtist() throws SQLException {
        String query = "select `artist id` from artist order by `artist id`";
        return getListString(query);
    }

    public String[] getListArtist() throws SQLException {
        String query = "select `artist name` from artist order by `artist id`";
        return getListString(query);
    }

    private String[] getListString(String query) throws SQLException {
        String list[];
        ResultSet hasil = con.getResult(query);
        int count = 0;
        while (hasil.next()) {
            count++;
        }
        hasil.beforeFirst();
        list = new String[count];
        int i = 0;
        while (hasil.next()) {
            list[i] = hasil.getString(1);
            i++;
        }
        return list;
    }

    public void create(String id, String artist) throws SQLException {
        String query = "INSERT INTO `artist`(`artist id`, `artist name`) VALUES ('" + id + "','" + artist + "')";
        con.execute(query);
    }

    public void update(String id, String artist) throws SQLException {
        String query = "UPDATE `artist` SET `artist name`='" + artist + "' WHERE `artist id`='" + id + "'";
        con.execute(query);
    }

    public void delete(String id) throws SQLException {
        String query = "DELETE FROM `artist` WHERE `artist id` = " + id;
        con.execute(query);
    }
}
