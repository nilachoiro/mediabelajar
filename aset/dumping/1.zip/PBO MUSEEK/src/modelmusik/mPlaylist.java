/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelmusik;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bedhu
 */
public class mPlaylist {

    private koneksi con;

    public mPlaylist() throws SQLException {
        con = new koneksi();
    }

    public DefaultTableModel getTabel(int id) throws SQLException {
        String judulkolom[] = {"Music ID", "Music Name", "Artist", "Genre"};
        DefaultTableModel modelTabel = new DefaultTableModel(null, judulkolom);
        try {
            String query = "SELECT p.`music id`, `music name`, `artist name`, `genre type` FROM `playlist` p JOIN `music` m ON (p.`music id` = m.`music id`) JOIN `genre` g ON (m.`genre id` = g.`genre id`) JOIN `artist` a ON (m.`artist id` = a.`artist id`) WHERE `user id` = " + id + " ORDER BY p.`music id`";
            ResultSet hasil = con.getResult(query);
            while (hasil.next()) {
                String kolom[] = new String[judulkolom.length];
                for (int i = 0; i < kolom.length; i++) {
                    kolom[i] = hasil.getString(i + 1);
                }
                modelTabel.addRow(kolom);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return modelTabel;
    }

    public boolean isSongExisted(String id, int idUser) throws SQLException {
        String query = "select * from `playlist` where `music id` = " + id + " and `user id` =" + idUser;
        ResultSet hasil = con.getResult(query);
        return hasil.next();
    }

    public int getid(String username) throws SQLException {
        String query = "SELECT `user id` FROM `account` WHERE `username` = '" + username + "'";
        ResultSet hasil = con.getResult(query);
        hasil.next();
        return hasil.getInt(1);
    }

    public void create(String idMusik, int idUser) throws SQLException {
        String query = "INSERT INTO `playlist`(`music id`, `user id`) VALUES ('" + idMusik + "','" + idUser + "')";
        con.execute(query);
    }

    public void delete(String id) throws SQLException {
        String query = "DELETE FROM `playlist` WHERE `music id` = " + id;
        con.execute(query);
    }
}
