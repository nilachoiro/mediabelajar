/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelmusik;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author bedhu
 */
public class mAccount {

    private koneksi con;

    public mAccount() throws SQLException {
        con = new koneksi();
    }

    public boolean checkusername(String username) throws SQLException {
        String query = "SELECT `username` FROM `account` WHERE `username` = '" + username + "'";
        ResultSet hasil = con.getResult(query);
        boolean valid;
        if (hasil.next()) {
            valid = true;
        } else {
            valid = false;
        }
        return valid;
    }

    public String checkpassword(String username) throws SQLException {
        String query = "SELECT `password` FROM `account` WHERE `username` = '" + username + "'";
        ResultSet hasil = con.getResult(query);
        hasil.next();
        return hasil.getString(1);
    }

    public String getstatus(String username) throws SQLException {
        String query = "SELECT `status` FROM `account` WHERE `username` = '" + username + "'";
        ResultSet hasil = con.getResult(query);
        hasil.next();
        return hasil.getString(1);
    }

    public String getpassword(String username) throws SQLException {
        String query = "SELECT `password` FROM `account` WHERE `username` = '" + username + "'";
        ResultSet hasil = con.getResult(query);
        hasil.next();
        return hasil.getString(1);
    }

    public void create(String username, String password) throws SQLException {
        String query = "INSERT INTO `account`(`username`, `password`, `status`) VALUES ('" + username + "','" + password + "','admin')";
        con.execute(query);
    }

    public void update(String username, String password) throws SQLException {
        String query = "UPDATE `account` SET `username`='" + username + "',`password`='" + password + "',`status`='admin' WHERE `username`='" + username + "'";
        con.execute(query);
    }
}
