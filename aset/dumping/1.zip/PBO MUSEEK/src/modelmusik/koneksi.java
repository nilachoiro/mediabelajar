/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelmusik;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Loadhi
 */
public class koneksi {

    private String host;
    private String db;
    private String username;
    private String password;
    private Connection con;
    private Statement stat;

    public koneksi() throws SQLException {
        username = "root";
        password = "";
        host = "localhost";
        db = "museek";
        String url = "jdbc:mysql://" + host + ":3306/" + db;
        con = DriverManager.getConnection(url, username, password);
        stat = (Statement) con.createStatement();
    }

    public void execute(String query) throws SQLException {
        stat.executeUpdate(query);
    }

    public ResultSet getResult(String query) throws SQLException {
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }

}
