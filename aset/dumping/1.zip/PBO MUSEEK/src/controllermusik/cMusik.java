/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelmusik.mArtist;
import modelmusik.mGenre;
import modelmusik.mMusik;
import viewmusik.vMusik;

/**
 *
 * @author bedhu
 */
public class cMusik {

    vMusik view;
    mMusik model;
    mArtist modelArtist;
    mGenre modelGenre;
    private String[] idArtist;
    private String[] idGenre;

    public cMusik() throws SQLException {
        view = new vMusik();
        model = new mMusik();
        modelArtist = new mArtist();
        modelGenre = new mGenre();

        idArtist = modelArtist.getIdArtist();
        idGenre = modelGenre.getIdGenre();
        for (int i = 0; i < modelArtist.getListArtist().length; i++) {
            view.artistBox().addItem(modelArtist.getListArtist()[i]);
        }
        for (int i = 0; i < modelGenre.getListGenre().length; i++) {
            view.genreBox().addItem(modelGenre.getListGenre()[i]);
        }
        view.artistBox().setSelectedIndex(-1);
        view.genreBox().setSelectedIndex(-1);
        view.setTabel(model.getTabel());
        view.setLocationRelativeTo(null);
        view.setVisible(true);

        view.fileButton().addActionListener(new file());
        view.fileChooserFrame().addActionListener(new fileChooser());
        view.tambahButton().addActionListener(new tambah());
        view.ubahButton().addActionListener(new ubah());
        view.hapusButton().addActionListener(new hapus());
        view.kembaliButton().addActionListener(new kembali());
    }

    private class file implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.fileChooserFrame().showSaveDialog(null);
        }
    }

    private class fileChooser implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.linkField().setText(view.fileChooserFrame().getSelectedFile().getAbsolutePath().replace("\\", "\\\\"));
        }
    }

    private class tambah implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty() && !view.getMusik().isEmpty() && view.getArtist() != -1 && view.getGenre() != -1 && !view.getLink().isEmpty()) {
                    if (!model.isIdExisted(view.getId())) {
                        model.create(view.getId(), view.getMusik(), idArtist[view.getArtist()], idGenre[view.getGenre()], view.getLink());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID sudah dipakai");
                    }
                } else {
                    view.message("Data tidak boleh kosong");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class ubah implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty() && !view.getMusik().isEmpty() && view.getArtist() != -1 && view.getGenre() != -1 && !view.getLink().isEmpty()) {
                    if (model.isIdExisted(view.getId())) {
                        model.update(view.getId(), view.getMusik(), idArtist[view.getArtist()], idGenre[view.getGenre()], view.getLink());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID tidak ditemukan");
                    }
                } else {
                    view.message("Data tidak boleh kosong");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class hapus implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty()) {
                    if (model.isIdExisted(view.getId())) {
                        model.delete(view.getId());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID tidak ditemukan");
                    }
                } else {
                    view.message("ID wajib disi");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class kembali implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cAdmin();
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
    }

    public void reset() {
        view.idField().setText("");
        view.musikField().setText("");
        view.artistBox().setSelectedIndex(-1);
        view.genreBox().setSelectedIndex(-1);
        view.linkField().setText("");
    }
}
