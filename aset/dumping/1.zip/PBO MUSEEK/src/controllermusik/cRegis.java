/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelmusik.mAccount;
import modelmusik.mAccount;
import viewmusik.vRegis;

/**
 *
 * @author Loadhi
 */
public class cRegis {

    vRegis view;
    mAccount model;

    public cRegis() throws SQLException {
        view = new vRegis();
        model = new mAccount();
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        view.finishButton(new cRegis.finishActionListener());
        view.cancelButton(new cRegis.cancelActionListener());
    }

    private class finishActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (view.confirm("Buat Akun Baru?") == JOptionPane.YES_OPTION) {
                    model.create(view.getName(), view.getPass());
                    view.message("Akun Berhasil Dibuat !");
                    view.dispose();
                    new cLogin();
                }

            } catch (SQLException ex) {
                Logger.getLogger(cRegis.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private class cancelActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cLogin();
            } catch (SQLException ex) {
                Logger.getLogger(cRegis.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
