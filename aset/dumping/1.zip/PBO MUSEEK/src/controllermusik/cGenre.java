/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelmusik.mGenre;
import viewmusik.vGenre;

/**
 *
 * @author bedhu
 */
public class cGenre {

    vGenre view;
    mGenre model;

    public cGenre() throws SQLException {
        view = new vGenre();
        model = new mGenre();

        view.setTabel(model.getTabel());
        view.setLocationRelativeTo(null);
        view.setVisible(true);

        view.tambahButton().addActionListener(new tambah());
        view.ubahButton().addActionListener(new ubah());
        view.hapusButton().addActionListener(new hapus());
        view.kembaliButton().addActionListener(new kembali());
    }

    private class tambah implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty() && !view.getGenre().isEmpty()) {
                    if (!model.isIdExisted(view.getId())) {
                        model.create(view.getId(), view.getGenre());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID sudah dipakai");
                    }
                } else {
                    view.message("Data tidak boleh kosong");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class ubah implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty() && !view.getGenre().isEmpty()) {
                    if (model.isIdExisted(view.getId())) {
                        model.update(view.getId(), view.getGenre());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID tidak ditemukan");
                    }
                } else {
                    view.message("Data tidak boleh kosong");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class hapus implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (!view.getId().isEmpty()) {
                    if (model.isIdExisted(view.getId())) {
                        model.delete(view.getId());
                        view.setTabel(model.getTabel());
                        reset();
                    } else {
                        view.message("ID tidak ditemukan");
                    }
                } else {
                    view.message("ID wajib disi");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
                view.message("Input Error");
            }
        }
    }

    private class kembali implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cAdmin();
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
    }

    public void reset() {
        view.idField().setText("");
        view.genreField().setText("");
    }
}
