/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import modelmusik.mMusik;
import modelmusik.mPlaylist;
import viewmusik.vUser;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class cUser {

    vUser view;
    mPlaylist model;
    mMusik modelMusik;
    String username;
    FileInputStream FIS;
    BufferedInputStream BIS;
    Player player;

    public cUser(String username) throws SQLException {
        view = new vUser();
        model = new mPlaylist();
        modelMusik = new mMusik();

        this.username = username;
        view.setTabel(model.getTabel(model.getid(username)));
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        view.deleteButton().addActionListener(new deleteAction());
        view.profilButton().addActionListener(new profilAction());
        view.searchButton().addActionListener(new searchAction());
        view.logoutButton().addActionListener(new logout());
        view.playButton().addActionListener(new playAction());
    }

    private class deleteAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                model.delete(view.getSong());
                view.setTabel(model.getTabel(model.getid(username)));
                view.message("Lagu berhasil dihapus");
            } catch (Exception ex) {
                view.message("Lagu belum dipilih");
                Logger.getLogger(cUser.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class profilAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            try {
                new cProfil(username);
            } catch (SQLException ex) {
                Logger.getLogger(cUser.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class searchAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            try {
                view.dispose();
                new cSearch(username);
            } catch (SQLException ex) {
                Logger.getLogger(cSearch.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
    }

    private class playAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.setMusic(view.getSongName());
            try {
                String link = modelMusik.getLink(view.getSong());
                Play(link);
            } catch (Exception ex) {
                ex.printStackTrace();
                view.message("Error Playing");
            }
        }
    }

    private class logout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (view.messageYesNo("Apakah anda yakin ingin logout?") == 0) {
                    view.dispose();
                    new cLogin();
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
    }

    public void Play(String path) {
        try {
            FIS = new FileInputStream(path);
            BIS = new BufferedInputStream(FIS);
            player = new Player(BIS);
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {
            Logger.getLogger(cUser.class.getName()).log(Level.SEVERE, null, ex);
        }
        new Thread() {
            @Override
            public void run() {
                try {
                    player.play();
                } catch (JavaLayerException ex) {
                    Logger.getLogger(cUser.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }.start();
    }
}
