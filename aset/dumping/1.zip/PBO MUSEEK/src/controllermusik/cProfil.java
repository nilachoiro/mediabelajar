/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelmusik.mAccount;
import modelmusik.mAccount;
import viewmusik.vProfil;

/**
 *
 * @author Loadhi
 */
public class cProfil {

    vProfil view;
    mAccount model;
    String username;

    public cProfil(String username) throws SQLException {
        view = new vProfil();
        model = new mAccount();
        this.username = username;
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        view.usernameField().setText(username);
        view.passField().setText(model.getpassword(username));
        view.backButton().addActionListener(new backActionListener());
        view.editButton().addActionListener(new editActionListener());
        view.okeButton().addActionListener(new okeActionListener());
        view.cancelButton().addActionListener(new cancelActionListener());
    }

    private class backActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            try {
                new cUser(username);
            } catch (SQLException ex) {
                Logger.getLogger(cProfil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class editActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.okeButton().setEnabled(true);
            view.cancelButton().setEnabled(true);
            view.usernameField().setEnabled(true);
            view.passField().setEnabled(true);
            view.editButton().setEnabled(false);
        }
    }

    private class okeActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                model.update(view.usernameField().getText(), view.passField().getText());
            } catch (SQLException ex) {
                Logger.getLogger(cProfil.class.getName()).log(Level.SEVERE, null, ex);
            }
            username = view.usernameField().getText();
            view.okeButton().setEnabled(false);
            view.cancelButton().setEnabled(false);
            view.usernameField().setEnabled(false);
            view.passField().setEnabled(false);
            view.editButton().setEnabled(true);
        }
    }

    private class cancelActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.okeButton().setEnabled(false);
            view.cancelButton().setEnabled(false);
            view.usernameField().setEnabled(false);
            view.passField().setEnabled(false);
            view.editButton().setEnabled(true);
        }
    }
}
