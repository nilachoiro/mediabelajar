/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelmusik.mMusik;
import modelmusik.mPlaylist;
import viewmusik.vSearch;

/**
 *
 * @author Loadhi
 */
public class cSearch {

    vSearch view;
    mMusik model;
    mPlaylist modelPlaylist;
    String username;

    public cSearch(String username) throws SQLException {
        view = new vSearch();
        model = new mMusik();
        modelPlaylist = new mPlaylist();
        this.username = username;
        view.setTabel(model.getTabel());
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        view.addButton().addActionListener(new add());
        view.backButton().addActionListener(new back());
    }

    private class add implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent s) {
            try {
                if (!modelPlaylist.isSongExisted(view.getSong(), modelPlaylist.getid(username))) {
                    modelPlaylist.create(view.getSong(), modelPlaylist.getid(username));
                    view.message("Lagu telah dimasukkan ke playlist");
                } else {
                    view.message("Lagu sudah ada playlist");
                }
            } catch (Exception ex) {
                view.message("Lagu belum dipilih");
                Logger.getLogger(cSearch.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class back implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent s) {
            view.dispose();
            try {
                new cUser(username);
            } catch (SQLException ex) {
                Logger.getLogger(cSearch.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
