/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelmusik.mAccount;
import modelmusik.mAccount;
import viewmusik.vLogin;

/**
 *
 * @author Loadhi
 */
public class cLogin {

    vLogin view;
    mAccount model;

    public cLogin() throws SQLException {
        view = new vLogin();
        model = new mAccount();
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        view.loginButton(new loginActionListener());
        view.registerButton(new registerActionListener());
    }

    private class loginActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (model.checkusername(view.getnama())) {
                    if (view.getword().equals(model.checkpassword(view.getnama()))) {
                        switch (model.getstatus(view.getnama())) {
                            case "admin":
                                view.message("Selamat datang admin");
                                view.dispose();
                                new cAdmin();
                                break;
                            case "user":
                                view.message("Selamat datang user");
                                new cUser (view.getnama());
                                view.dispose();
                                break;
                               
                        }
                    } else {
                        view.message("Password salah");
                    }
                } else {
                    view.message("Username tidak ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(cLogin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class registerActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cRegis();
            } catch (SQLException ex) {
                Logger.getLogger(cLogin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
