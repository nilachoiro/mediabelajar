/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllermusik;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import viewmusik.vAdmin;

/**
 *
 * @author Loadhi
 */
public class cAdmin {

    vAdmin view;

    public cAdmin() throws SQLException {
        view = new vAdmin();

        view.setLocationRelativeTo(null);
        view.setVisible(true);

        view.artistButton().addActionListener(new artist());
        view.genreButton().addActionListener(new genre());
        view.musikButton().addActionListener(new musik());
        view.logoutButton().addActionListener(new logout());
    }

    private class artist implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cArtist();
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private class genre implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cGenre();
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class musik implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new cMusik();
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class logout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (view.messageYesNo("Apakah anda yakin ingin logout?") == 0) {
                    view.dispose();
                    new cLogin();
                }
            } catch (SQLException ex) {
                Logger.getLogger(cAdmin.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
    }
}
